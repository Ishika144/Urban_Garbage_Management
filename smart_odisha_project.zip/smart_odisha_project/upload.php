<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('Location: public-login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Profile Picture - Smart Odisha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .upload-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 500px;
            position: relative;
        }
        
        .upload-header {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }
        
        .upload-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
        }
        
        .upload-header h3 {
            font-weight: 600;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }
        
        .upload-header p {
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }
        
        .upload-body {
            padding: 40px;
        }
        
        .file-upload-area {
            border: 2px dashed #27ae60;
            border-radius: 15px;
            padding: 40px 20px;
            text-align: center;
            background: #f8f9fa;
            transition: all 0.3s ease;
            margin-bottom: 30px;
        }
        
        .file-upload-area:hover {
            border-color: #2ecc71;
            background: #e8f5e8;
        }
        
        .file-upload-area i {
            font-size: 3rem;
            color: #27ae60;
            margin-bottom: 15px;
        }
        
        .file-upload-area h5 {
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .file-upload-area p {
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        
        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        
        .form-control:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
            background: white;
        }
        
        .btn-upload {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .back-link {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            text-decoration: none;
            font-size: 1.2rem;
            transition: all 0.3s ease;
            z-index: 2;
        }
        
        .back-link:hover {
            color: #f8f9fa;
            transform: translateX(-5px);
        }
        
        .file-info {
            background: #e8f5e8;
            border: 1px solid #27ae60;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
            display: none;
        }
        
        .file-info.show {
            display: block;
        }
        
        @media (max-width: 480px) {
            .upload-container {
                margin: 10px;
            }
            
            .upload-body {
                padding: 30px 20px;
            }
            
            .upload-header {
                padding: 25px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="upload-container">
        <a href="public.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
        </a>
        
        <div class="upload-header">
            <h3><i class="fas fa-camera me-2"></i>Upload Profile Picture</h3>
            <p>Choose a clear photo to update your profile</p>
        </div>
        
        <div class="upload-body">
            <form method="POST" action="image-upload.php" enctype="multipart/form-data">
                <div class="file-upload-area" id="uploadArea">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <h5>Choose your profile picture</h5>
                    <p>Click to browse or drag and drop</p>
                    <p class="text-muted">JPG, PNG, GIF up to 5MB</p>
                </div>
                
                <div class="form-group">
                    <input class="form-control" type="file" name="uploadfile" id="fileInput" accept="image/*" required />
                </div>
                
                <div class="file-info" id="fileInfo">
                    <h6><i class="fas fa-info-circle me-2"></i>Selected File:</h6>
                    <p id="fileName"></p>
                    <p id="fileSize"></p>
                </div>
                
                <div class="mt-4">
                    <button class="btn btn-upload" type="submit" name="upload">
                        <i class="fas fa-upload me-2"></i>Upload Picture
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-4">
                <a href="public.php" class="text-decoration-none">
                    <i class="fas fa-home me-2"></i>Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // File input handling
        const fileInput = document.getElementById('fileInput');
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const uploadArea = document.getElementById('uploadArea');
        
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Show file info
                fileName.textContent = file.name;
                fileSize.textContent = `Size: ${(file.size / 1024 / 1024).toFixed(2)} MB`;
                fileInfo.classList.add('show');
                
                // Update upload area
                uploadArea.innerHTML = `
                    <i class="fas fa-check-circle" style="color: #27ae60;"></i>
                    <h5 style="color: #27ae60;">File Selected</h5>
                    <p>${file.name}</p>
                `;
            } else {
                fileInfo.classList.remove('show');
                uploadArea.innerHTML = `
                    <i class="fas fa-cloud-upload-alt"></i>
                    <h5>Choose your profile picture</h5>
                    <p>Click to browse or drag and drop</p>
                    <p class="text-muted">JPG, PNG, GIF up to 5MB</p>
                `;
            }
        });
        
        // Drag and drop functionality
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#2ecc71';
            uploadArea.style.background = '#e8f5e8';
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#27ae60';
            uploadArea.style.background = '#f8f9fa';
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#27ae60';
            uploadArea.style.background = '#f8f9fa';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                fileInput.dispatchEvent(new Event('change'));
            }
        });
        
        // Click to upload
        uploadArea.addEventListener('click', function() {
            fileInput.click();
        });
    </script>
</body>
</html>
