-- Create database if not exists
CREATE DATABASE IF NOT EXISTS garbage_manage;
USE garbage_manage;

-- Table structure for table `government_data`
CREATE TABLE IF NOT EXISTS `government_data` (
  `gid` int(11) NOT NULL,
  `password` int(11) NOT NULL,
  `state` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert government data
INSERT INTO `government_data` (`gid`, `password`, `state`, `country`) VALUES
(1, 345, 'Odisha', 'India')
ON DUPLICATE KEY UPDATE gid=gid;

-- Table structure for table `health_care_data`
CREATE TABLE IF NOT EXISTS `health_care_data` (
  `hid` int(11) NOT NULL,
  `hname` varchar(30) DEFAULT NULL,
  `hgender` varchar(3) DEFAULT NULL,
  `hdept` varchar(30) DEFAULT NULL,
  `hdp` varchar(50) DEFAULT NULL,
  `hpassword` varchar(10) NOT NULL,
  `hphone` bigint(15) NOT NULL,
  `hemail` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample healthcare data
INSERT INTO `health_care_data` (`hid`, `hname`, `hgender`, `hdept`, `hdp`, `hpassword`, `hphone`, `hemail`) VALUES
(2443, 'shyam kumar', 'M', 'provider', 'shyam.jpg', 'fgh', 5678765645, 'shyam@gmail.com')
ON DUPLICATE KEY UPDATE hid=hid;

-- Table structure for table `health_care_work`
CREATE TABLE IF NOT EXISTS `health_care_work` (
  `hwid` int(11) NOT NULL AUTO_INCREMENT,
  `hid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `h_w_desc` varchar(100) NOT NULL,
  `w_image` varchar(50) NOT NULL,
  `w_address` varchar(30) NOT NULL,
  `w_city` varchar(30) NOT NULL,
  `w_type` varchar(30) NOT NULL,
  `w_status` varchar(30) NOT NULL,
  PRIMARY KEY (`hwid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `officer_data`
CREATE TABLE IF NOT EXISTS `officer_data` (
  `ofid` int(11) DEFAULT NULL,
  `ofname` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `dept` varchar(30) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `gender` varchar(3) NOT NULL,
  `profile_img` varchar(30) NOT NULL,
  `phone` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample officer data
INSERT INTO `officer_data` (`ofid`, `ofname`, `email`, `dob`, `dept`, `password`, `gender`, `profile_img`, `phone`) VALUES
(234, 'ranjan kumar', 'ranjan@gmail.com', '2022-11-16', 'Cleaning Authority', 'dfg', 'M', '2141013024.jpg', 347689657)
ON DUPLICATE KEY UPDATE ofid=ofid;

-- Table structure for table `ppp_data`
CREATE TABLE IF NOT EXISTS `ppp_data` (
  `ppp_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `ppp_dp` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` bigint(20) NOT NULL,
  PRIMARY KEY (`ppp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample PPP data
INSERT INTO `ppp_data` (`ppp_id`, `name`, `gender`, `password`, `ppp_dp`, `email`, `phone`) VALUES
(2, 'sankar mohanty', 'M', 'dfg', 'sankar.jfif', 'sankar@gmail.com', 3453465734)
ON DUPLICATE KEY UPDATE ppp_id=ppp_id;

-- Table structure for table `ppp_work_update`
CREATE TABLE IF NOT EXISTS `ppp_work_update` (
  `work_id` int(11) NOT NULL AUTO_INCREMENT,
  `ppp_id` int(11) NOT NULL,
  `work_image` varchar(50) NOT NULL,
  `type` varchar(30) NOT NULL,
  `amount_recycle` int(11) NOT NULL,
  `status` varchar(30) NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`work_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `public_complaint`
CREATE TABLE IF NOT EXISTS `public_complaint` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `comp_type` varchar(30) NOT NULL,
  `c_phone` bigint(20) NOT NULL,
  `comp_sts` varchar(10) NOT NULL,
  `comp_desc` varchar(100) NOT NULL,
  `c_img` varchar(30) NOT NULL,
  `c_address` varchar(30) NOT NULL,
  `c_city` varchar(30) NOT NULL,
  `c_date` date NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `public_data`
CREATE TABLE IF NOT EXISTS `public_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(2) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `sig_in_dt` datetime NOT NULL,
  `file_name` varchar(225) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `public_work`
CREATE TABLE IF NOT EXISTS `public_work` (
  `wid` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `UNIT` varchar(10) DEFAULT NULL,
  `city` varchar(15) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `idate` date DEFAULT NULL,
  `employee` varchar(30) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`wid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `worker_data`
CREATE TABLE IF NOT EXISTS `worker_data` (
  `worker_id` int(11) NOT NULL AUTO_INCREMENT,
  `worker_name` varchar(30) NOT NULL,
  `wor_email` varchar(30) NOT NULL,
  `wor_phone` bigint(15) NOT NULL,
  `wor_gender` varchar(3) NOT NULL,
  `wor_dp` varchar(30) NOT NULL,
  `wor_dept` varchar(30) NOT NULL,
  `wor_address` varchar(50) NOT NULL,
  `wor_city` varchar(30) NOT NULL,
  `w_password` varchar(30) NOT NULL,
  PRIMARY KEY (`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample worker data
INSERT INTO `worker_data` (`worker_id`, `worker_name`, `wor_email`, `wor_phone`, `wor_gender`, `wor_dp`, `wor_dept`, `wor_address`, `wor_city`, `w_password`) VALUES
(1, 'santosh kumar', 'santosh@gmail.com', 3546284638, 'M', 'santosh.JPG', 'cleaning', 'jagamara', 'Bhubaneswar', 'vbn'),
(2, 'haris kumar', 'harish@gmail.com', 7865674534, 'M', 'harish.jpg', 'cleaning', 'jagamara', 'Bhubaneswar', 'zxc')
ON DUPLICATE KEY UPDATE worker_id=worker_id;

-- Table structure for table `worker_work`
CREATE TABLE IF NOT EXISTS `worker_work` (
  `wid` int(11) NOT NULL,
  `w_image` varchar(30) NOT NULL,
  `worker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

