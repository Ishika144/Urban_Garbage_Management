<?php
include 'connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    // Basic validation
    if (empty($email) || empty($password)) {
        header('Location: public-login.php?error=empty_fields');
        exit();
    }
    
    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header('Location: public-login.php?error=invalid_email');
        exit();
    }
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM public_data WHERE email = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $email, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        $count = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);
        
        if ($count == 1) {
            // Start session and store user data
            session_start();
            $_SESSION['id'] = $row['id'];
            $_SESSION['fname'] = $row['fname'];
            $_SESSION['lname'] = $row['lname'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['phone'] = $row['phone'];
            $_SESSION['gender'] = $row['gender'];
            $_SESSION['dob'] = $row['dob'];
            $_SESSION['image'] = $row['file_name'] ?: 'default.jpg';
            
            // Redirect to dashboard
            header('Location: public.php');
            exit();
        } else {
            // Invalid credentials
            header('Location: public-login.php?error=invalid_credentials');
            exit();
        }
        
        mysqli_stmt_close($stmt);
    } else {
        // Database error
        header('Location: public-login.php?error=database_error');
        exit();
    }
} else {
    // If accessed directly without POST
    header('Location: public-login.php');
    exit();
}

mysqli_close($conn);
?>