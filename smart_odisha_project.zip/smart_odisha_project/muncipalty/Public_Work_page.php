<?php
session_start();
include '../connection.php';

// Check if officer is logged in
if (!isset($_SESSION['ofd'])) {
    header('Location: officer-login.php');
    exit();
}

$sql = "SELECT * FROM public_work,public_data WHERE public_work.id = public_data.id ORDER BY public_work.wid DESC";
$result = mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Public Work Management - Officer Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #e74c3c;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .work-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .work-table h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background: #e74c3c;
            color: white;
            border: none;
            font-weight: 600;
            padding: 15px;
        }
        
        .table tbody tr:hover {
            background: rgba(231, 76, 60, 0.1);
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
        }
        
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        
        .btn-view {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .btn-assign {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .btn-assign:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .back-btn {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-right: 10px;
        }
        
        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .form-select {
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 8px 12px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }
        
        .form-select:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .work-table {
                margin-bottom: 20px;
                padding: 20px;
            }
            
            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="OFFICER_PAGE.php">
                <i class="fas fa-user-tie"></i>Officer Dashboard
            </a>
            <div class="ms-auto">
                <a href="OFFICER_PAGE.php" class="back-btn">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
                <a href="log-out.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <div class="work-table">
                <h3><i class="fas fa-trash me-2"></i>Public Work Management</h3>
                
                <?php if (mysqli_num_rows($result) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user me-2"></i>Name</th>
                                <th><i class="fas fa-hashtag me-2"></i>Work ID</th>
                                <th><i class="fas fa-map-marker-alt me-2"></i>Address</th>
                                <th><i class="fas fa-building me-2"></i>Unit</th>
                                <th><i class="fas fa-map me-2"></i>Location</th>
                                <th><i class="fas fa-image me-2"></i>Photo</th>
                                <th><i class="fas fa-calendar me-2"></i>Date</th>
                                <th><i class="fas fa-info-circle me-2"></i>Status</th>
                                <th><i class="fas fa-user-cog me-2"></i>Employee</th>
                                <th><i class="fas fa-tasks me-2"></i>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($row['wid']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                <td><?php echo htmlspecialchars($row['UNIT']); ?></td>
                                <td>
                                    <a href="maps_plot.php?id=<?php echo $row['wid']; ?>" 
                                       target="_blank" 
                                       class="btn btn-view">
                                        <i class="fas fa-map-marker-alt me-1"></i>View
                                    </a>
                                </td>
                                <td>
                                    <a href="../public-garbage-image/<?php echo htmlspecialchars($row['image']); ?>" 
                                       target="_blank" 
                                       class="btn btn-view">
                                        <i class="fas fa-eye me-1"></i>View
                                    </a>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($row['idate'])); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $row['status'] == 'Approved' ? 'status-approved' : 'status-pending'; ?>">
                                        <?php echo htmlspecialchars($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['employee']): ?>
                                        <span class="badge bg-success"><?php echo htmlspecialchars($row['employee']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Unassigned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="public_work_assign.php" method="POST" class="d-inline">
                                        <select class="form-select mb-2" name="wor_id" required>
                                            <option selected disabled value="">Select Employee</option>
                                            <option value="1">Santosh Kumar</option>
                                            <option value="2">Harish Kumar</option>
                                        </select>
                                        <input type="hidden" name="wid" value="<?php echo $row['wid']; ?>">
                                        <button type="submit" class="btn btn-assign">
                                            <i class="fas fa-user-plus me-1"></i>Assign
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <h4>No Public Work Requests</h4>
                    <p>There are no public work requests to display at the moment.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>