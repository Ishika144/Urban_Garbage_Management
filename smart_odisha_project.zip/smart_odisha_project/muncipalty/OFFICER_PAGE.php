<?php
session_start();
include '../connection.php';

// Check if officer is logged in
if (!isset($_SESSION['ofd'])) {
    header('Location: officer-login.php');
    exit();
}

// Get statistics
$officer_id = $_SESSION['ofd'];

// Count pending work
$pending_sql = "SELECT COUNT(*) as pending_count FROM public_work WHERE status = 'pending'";
$pending_result = mysqli_query($conn, $pending_sql);
$pending_count = mysqli_fetch_assoc($pending_result)['pending_count'];

// Count completed work
$completed_sql = "SELECT COUNT(*) as completed_count FROM public_work WHERE status = 'Approved'";
$completed_result = mysqli_query($conn, $completed_sql);
$completed_count = mysqli_fetch_assoc($completed_result)['completed_count'];

// Count total complaints
$complaints_sql = "SELECT COUNT(*) as complaints_count FROM public_complaint";
$complaints_result = mysqli_query($conn, $complaints_sql);
$complaints_count = mysqli_fetch_assoc($complaints_result)['complaints_count'];

// Count open complaints
$open_complaints_sql = "SELECT COUNT(*) as open_count FROM public_complaint WHERE comp_sts = 'open'";
$open_complaints_result = mysqli_query($conn, $open_complaints_sql);
$open_complaints_count = mysqli_fetch_assoc($open_complaints_result)['open_count'];

$total_work = $pending_count + $completed_count;
$completion_rate = $total_work > 0 ? round(($completed_count / $total_work) * 100) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officer Dashboard - Smart Odisha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #e74c3c;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .welcome-section h2 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .welcome-section p {
            color: #7f8c8d;
            margin-bottom: 0;
        }
        
        .profile-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .profile-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #e74c3c;
            margin-bottom: 20px;
        }
        
        .profile-info h4 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .profile-info p {
            color: #7f8c8d;
            margin-bottom: 8px;
        }
        
        .profile-info strong {
            color: #2c3e50;
        }
        
        .stats-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .stats-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stats-label {
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        
        .action-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .action-card h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .btn-action {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 15px 30px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            transition: all 0.3s ease;
            min-width: 200px;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .btn-action.blue {
            background: linear-gradient(135deg, #3498db, #2980b9);
        }
        
        .btn-action.blue:hover {
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.3);
        }
        
        .btn-action.green {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
        }
        
        .btn-action.green:hover {
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
        }
        
        .btn-action.orange {
            background: linear-gradient(135deg, #f39c12, #e67e22);
        }
        
        .btn-action.orange:hover {
            box-shadow: 0 10px 20px rgba(243, 156, 18, 0.3);
        }
        
        .progress-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .progress-item {
            margin-bottom: 20px;
        }
        
        .progress-item:last-child {
            margin-bottom: 0;
        }
        
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-weight: 500;
            color: #2c3e50;
        }
        
        .progress {
            height: 10px;
            border-radius: 5px;
            background: #ecf0f1;
        }
        
        .progress-bar {
            border-radius: 5px;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .welcome-section,
            .profile-card,
            .stats-card,
            .action-card,
            .progress-section {
                margin-bottom: 20px;
                padding: 20px;
            }
            
            .btn-action {
                min-width: 100%;
                margin: 5px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-user-tie"></i>Officer Dashboard
            </a>
            <div class="ms-auto">
                <a href="log-out.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['ofname']); ?>!</h2>
                        <p>Manage garbage collection, complaints, and municipal services efficiently.</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <small class="text-muted"><?php echo date('l, F j, Y'); ?></small>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Profile Card -->
                <div class="col-lg-4">
                    <div class="profile-card">
                        <div class="text-center">
                            <img src="../profile-image/<?php echo htmlspecialchars($_SESSION['profile_img']); ?>" 
                                 alt="Profile" 
                                 class="profile-image"
                                 onerror="this.src='../profile-image/default.jpg'">
                            
                            <div class="profile-info">
                                <h4><?php echo htmlspecialchars($_SESSION['ofname']); ?></h4>
                                <p><strong>Department:</strong> <?php echo htmlspecialchars($_SESSION['dept']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($_SESSION['email']); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($_SESSION['phone']); ?></p>
                                <p><strong>DOB:</strong> <?php echo htmlspecialchars($_SESSION['dob']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="stats-card text-center">
                                <i class="fas fa-clock stats-icon text-warning"></i>
                                <div class="stats-number text-warning"><?php echo $pending_count; ?></div>
                                <div class="stats-label">Pending Work</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-card text-center">
                                <i class="fas fa-check-circle stats-icon text-success"></i>
                                <div class="stats-number text-success"><?php echo $completed_count; ?></div>
                                <div class="stats-label">Completed Work</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-card text-center">
                                <i class="fas fa-exclamation-triangle stats-icon text-danger"></i>
                                <div class="stats-number text-danger"><?php echo $open_complaints_count; ?></div>
                                <div class="stats-label">Open Complaints</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="stats-card text-center">
                                <i class="fas fa-chart-line stats-icon text-info"></i>
                                <div class="stats-number text-info"><?php echo $completion_rate; ?>%</div>
                                <div class="stats-label">Completion Rate</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Progress Section -->
            <div class="progress-section">
                <h3 class="text-center mb-4">Work Progress Overview</h3>
                <div class="row">
                    <div class="col-md-6">
                        <div class="progress-item">
                            <div class="progress-label">
                                <span>Garbage Collection</span>
                                <span><?php echo $completion_rate; ?>%</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-success" style="width: <?php echo $completion_rate; ?>%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="progress-item">
                            <div class="progress-label">
                                <span>Complaint Resolution</span>
                                <span><?php echo $complaints_count > 0 ? round((($complaints_count - $open_complaints_count) / $complaints_count) * 100) : 0; ?>%</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-info" style="width: <?php echo $complaints_count > 0 ? (($complaints_count - $open_complaints_count) / $complaints_count) * 100 : 0; ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="action-card">
                <h3>Quick Actions</h3>
                <div class="row text-center">
                    <div class="col-md-6 col-lg-3">
                        <a href="Public_Work_page.php" class="btn btn-action blue">
                            <i class="fas fa-trash me-2"></i>Public Work
                        </a>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <a href="public_complaint.php" class="btn btn-action">
                            <i class="fas fa-exclamation-circle me-2"></i>Complaints
                        </a>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <a href="pppworktable_for_offocer.php" class="btn btn-action green">
                            <i class="fas fa-recycle me-2"></i>PPP Work
                        </a>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <a href="health_care_data_for_officer.php" class="btn btn-action orange">
                            <i class="fas fa-heartbeat me-2"></i>Health Data
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>