<?php
include 'connection.php';     
$showAlert = false; 
$showError = false; 
$exists = false;
    
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $phone = $_POST['phone'];

    $sql = "Select * from public_data where email='$email'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result); 
    
    if($num == 0) {
        if(($password == $cpassword) && $exists == false) {
            $sql = "INSERT INTO public_data (fname,lname,dob,gender,email,phone,password,sig_in_dt)VALUES('$fname','$lname','$dob','$gender','$email',$phone,'$password',current_timestamp())";
    
            $result = mysqli_query($conn, $sql);
    
            if ($result) {
                $showAlert = true; 
            }
        } 
        else { 
            $showError = "Passwords do not match"; 
        }      
    }
    
    if($num > 0) {
        $exists = "Email already exists"; 
    } 
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Public Registration - Smart Odisha</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .registration-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            max-width: 800px;
            margin: 20px auto;
            position: relative;
        }
        
        .registration-header {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            color: white;
            padding: 40px;
            text-align: center;
            position: relative;
        }
        
        .registration-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/><circle cx="10" cy="60" r="0.5" fill="white" opacity="0.1"/><circle cx="90" cy="40" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
        }
        
        .registration-header h3 {
            font-weight: 600;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
        }
        
        .registration-header p {
            opacity: 0.9;
            position: relative;
            z-index: 1;
        }
        
        .registration-body {
            padding: 40px;
        }
        
        .form-label {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .form-control {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        
        .form-control:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
            background: white;
        }
        
        .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        
        .form-select:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
            background: white;
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .back-link {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            text-decoration: none;
            font-size: 1.2rem;
            transition: all 0.3s ease;
            z-index: 2;
        }
        
        .back-link:hover {
            color: #f8f9fa;
            transform: translateX(-5px);
        }
        
        .alert {
            border-radius: 10px;
            border: none;
            margin-bottom: 20px;
            padding: 15px 20px;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724;
        }
        
        .alert-danger {
            background: linear-gradient(135deg, #f8d7da, #f5c6cb);
            color: #721c24;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
        }
        
        .login-link a {
            color: #27ae60;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .login-link a:hover {
            color: #2ecc71;
        }
        
        @media (max-width: 768px) {
            .registration-container {
                margin: 10px;
            }
            
            .registration-body {
                padding: 30px 20px;
            }
            
            .registration-header {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="registration-container">
        <a href="index.php" class="back-link">
            <i class="fas fa-arrow-left"></i>
        </a>
        
        <div class="registration-header">
            <h3><i class="fas fa-user-plus me-2"></i>Create Account</h3>
            <p>Join Smart Odisha and contribute to a cleaner environment</p>
        </div>
        
        <div class="registration-body">
            <?php
            if($showAlert) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>
                    <strong>Success!</strong> Your account has been created successfully. You can now <a href="public-login.php" class="alert-link">login</a>.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>';
            }
            
            if($showError) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <strong>Error!</strong> ' . $showError . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>';
            }
            
            if($exists) {
                echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    <strong>Error!</strong> ' . $exists . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>';
            }
            ?>
            
            <form action="public-sign-up.php" method="post">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="firstName">
                            <i class="fas fa-user me-2"></i>First Name
                        </label>
                        <input type="text" id="firstName" class="form-control" name="firstname" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="lastName">
                            <i class="fas fa-user me-2"></i>Last Name
                        </label>
                        <input type="text" id="lastName" class="form-control" name="lastname" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="dob">
                            <i class="fas fa-calendar me-2"></i>Date of Birth
                        </label>
                        <input type="date" id="dob" class="form-control" name="dob" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="gender">
                            <i class="fas fa-venus-mars me-2"></i>Gender
                        </label>
                        <select class="form-select" name="gender" required>
                            <option value="">Select Gender</option>
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                            <option value="O">Other</option>
                        </select>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="email">
                            <i class="fas fa-envelope me-2"></i>Email Address
                        </label>
                        <input type="email" id="email" class="form-control" name="email" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="phone">
                            <i class="fas fa-phone me-2"></i>Phone Number
                        </label>
                        <input type="tel" id="phone" class="form-control" name="phone" required>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="password">
                            <i class="fas fa-lock me-2"></i>Password
                        </label>
                        <input type="password" id="password" class="form-control" name="password" required>
                    </div>
                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label" for="cpassword">
                            <i class="fas fa-lock me-2"></i>Confirm Password
                        </label>
                        <input type="password" id="cpassword" class="form-control" name="cpassword" required>
                    </div>
                </div>
                
                <div class="mt-4">
                    <button type="submit" class="btn btn-submit">
                        <i class="fas fa-user-plus me-2"></i>Create Account
                    </button>
                </div>
            </form>
            
            <div class="login-link">
                <p>Already have an account? <a href="public-login.php">Sign In</a></p>
                <p><a href="index.php"><i class="fas fa-home me-2"></i>Back to Home</a></p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const password = document.getElementById('password');
            const cpassword = document.getElementById('cpassword');
            
            form.addEventListener('submit', function(e) {
                if (password.value !== cpassword.value) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                    return;
                }
                
                if (password.value.length < 6) {
                    e.preventDefault();
                    alert('Password must be at least 6 characters long!');
                    return;
                }
            });
            
            // Real-time password confirmation
            cpassword.addEventListener('input', function() {
                if (password.value !== cpassword.value) {
                    cpassword.setCustomValidity('Passwords do not match');
                } else {
                    cpassword.setCustomValidity('');
                }
            });
            
            // Add some interactive effects
            const inputs = document.querySelectorAll('.form-control, .form-select');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
        });
    </script>
</body>
</html>