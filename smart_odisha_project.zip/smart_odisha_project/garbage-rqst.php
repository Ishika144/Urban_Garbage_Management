<?php
include 'connection.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header('Location: public-login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['id'];
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $unit = trim($_POST['unit']);
    $latitude = isset($_POST['latitude']) ? floatval($_POST['latitude']) : 0;
    $longitude = isset($_POST['longitude']) ? floatval($_POST['longitude']) : 0;
    
    // Basic validation
    if (empty($address) || empty($city) || empty($unit)) {
        header('Location: public_work_page_for_p.php?error=empty_fields');
        exit();
    }
    
    // Handle file upload
    $image_name = '';
    if (isset($_FILES['uploadfile']) && $_FILES['uploadfile']['error'] == UPLOAD_ERR_OK) {
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];
        $filesize = $_FILES["uploadfile"]["size"];
        $filetype = $_FILES["uploadfile"]["type"];
        
        // Validate file type
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        if (!in_array($filetype, $allowed_types)) {
            header('Location: public_work_page_for_p.php?error=invalid_file_type');
            exit();
        }
        
        // Validate file size (max 5MB)
        if ($filesize > 5 * 1024 * 1024) {
            header('Location: public_work_page_for_p.php?error=file_too_large');
            exit();
        }
        
        // Generate unique filename
        $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
        $image_name = 'garbage_' . $user_id . '_' . time() . '.' . $file_extension;
        $folder = "./public-garbage-image/" . $image_name;
        
        // Move uploaded file
        if (!move_uploaded_file($tempname, $folder)) {
            header('Location: public_work_page_for_p.php?error=upload_failed');
            exit();
        }
    }
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "INSERT INTO public_work (id, address, UNIT, city, image, idate, latitude, longitude, status) 
            VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?, 'pending')";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issssdd", $user_id, $address, $unit, $city, $image_name, $latitude, $longitude);
        
        if (mysqli_stmt_execute($stmt)) {
            header('Location: public_work_page_for_p.php?success=request_submitted');
        } else {
            header('Location: public_work_page_for_p.php?error=database_error');
        }
        
        mysqli_stmt_close($stmt);
    } else {
        header('Location: public_work_page_for_p.php?error=database_error');
    }
} else {
    header('Location: public_work_page_for_p.php');
}

mysqli_close($conn);
?>