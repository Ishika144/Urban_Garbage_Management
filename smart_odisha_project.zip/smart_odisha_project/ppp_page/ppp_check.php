<?php
include '../connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Basic validation
    if (empty($email) || empty($password)) {
        header('Location: public_sign_in.php?error=empty_fields');
        exit();
    }

    // Validate PPP ID is numeric
    if (!is_numeric($email)) {
        header('Location: public_sign_in.php?error=invalid_credentials');
        exit();
    }

    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM ppp_data WHERE ppp_id = ? AND password = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $email, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $count = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);

        if ($count == 1) {
            // Start session and store PPP data
            session_start();
            $_SESSION['ppp_id'] = $row['ppp_id'];
            $_SESSION['name'] = $row['name'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['phone'] = $row['phone'];
            $_SESSION['gender'] = $row['gender'];
            $_SESSION['ppp_dp'] = $row['ppp_dp'];

            // Redirect to PPP dashboard
            header('Location: ppp_profile.php');
            exit();
        } else {
            // Invalid credentials
            header('Location: public_sign_in.php?error=invalid_credentials');
            exit();
        }

        mysqli_stmt_close($stmt);
    } else {
        // Database error
        header('Location: public_sign_in.php?error=database_error');
        exit();
    }
} else {
    // If accessed directly without POST
    header('Location: public_sign_in.php');
    exit();
}

mysqli_close($conn);
?>