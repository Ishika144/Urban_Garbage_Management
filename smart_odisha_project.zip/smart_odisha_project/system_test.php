<?php
session_start();
include 'connection.php';

// Test database connection
$db_status = "✅ Connected";
try {
    $test_query = "SELECT 1";
    $result = mysqli_query($conn, $test_query);
    if (!$result) {
        $db_status = "❌ Database Error: " . mysqli_error($conn);
    }
} catch (Exception $e) {
    $db_status = "❌ Connection Error: " . $e->getMessage();
}

// Test directory structure
$directories = [
    'health_care' => 'health_care/',
    'muncipalty' => 'muncipalty/',
    'ppp_page' => 'ppp_page/',
    'worker_site' => 'worker_site/',
    'government-site' => 'government-site/',
    'profile-image' => 'profile-image/',
    'public_complain_image' => 'public_complain_image/',
    'public-garbage-image' => 'public-garbage-image/',
    'health_care_image' => 'health_care_image/',
    'worker_work_image' => 'worker_work_image/',
    'ppp_work_image' => 'ppp_work_image/'
];

$dir_status = [];
foreach ($directories as $name => $path) {
    if (is_dir($path)) {
        $dir_status[$name] = "✅ Exists";
    } else {
        $dir_status[$name] = "❌ Missing";
    }
}

// Test key files
$files = [
    'connection.php' => 'connection.php',
    'index.php' => 'index.php',
    'public-login.php' => 'public-login.php',
    'public-sign-up.php' => 'public-sign-up.php',
    'public.php' => 'public.php',
    'health_care/health_care_login.php' => 'health_care/health_care_login.php',
    'health_care/health_care_work_check.php' => 'health_care/health_care_work_check.php',
    'muncipalty/officer-login.php' => 'muncipalty/officer-login.php',
    'muncipalty/OFFICER_PAGE.php' => 'muncipalty/OFFICER_PAGE.php',
    'ppp_page/public_sign_in.php' => 'ppp_page/public_sign_in.php',
    'worker_site/worker_sign_in.php' => 'worker_site/worker_sign_in.php',
    'worker_site/WorkerProfile.html' => 'worker_site/WorkerProfile.html',
    'government-site/government_page.html' => 'government-site/government_page.html'
];

$file_status = [];
foreach ($files as $name => $path) {
    if (file_exists($path)) {
        $file_status[$name] = "✅ Exists";
    } else {
        $file_status[$name] = "❌ Missing";
    }
}

// Test database tables
$tables = [
    'public_data',
    'public_work',
    'public_complaint',
    'officer_data',
    'health_care_data',
    'health_care_work',
    'ppp_data',
    'ppp_work_update',
    'worker_data',
    'worker_work',
    'government_data'
];

$table_status = [];
foreach ($tables as $table) {
    $query = "SHOW TABLES LIKE '$table'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        $table_status[$table] = "✅ Exists";
    } else {
        $table_status[$table] = "❌ Missing";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Odisha System Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px 0;
        }
        .test-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .status-item {
            padding: 10px;
            margin: 5px 0;
            border-radius: 8px;
            background: #f8f9fa;
        }
        .test-section {
            margin-bottom: 30px;
        }
        .test-section h3 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="text-center mb-4">
            <h1><i class="fas fa-cogs"></i> Smart Odisha System Test</h1>
            <p class="lead">Comprehensive system verification and diagnostics</p>
        </div>

        <!-- Database Connection Test -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-database"></i> Database Connection</h3>
                <div class="status-item">
                    <strong>Connection Status:</strong> <?php echo $db_status; ?>
                </div>
            </div>
        </div>

        <!-- Directory Structure Test -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-folder"></i> Directory Structure</h3>
                <div class="row">
                    <?php foreach ($dir_status as $name => $status): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="status-item">
                            <strong><?php echo $name; ?>:</strong> <?php echo $status; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- File Structure Test -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-file"></i> Key Files</h3>
                <div class="row">
                    <?php foreach ($file_status as $name => $status): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="status-item">
                            <strong><?php echo $name; ?>:</strong> <?php echo $status; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Database Tables Test -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-table"></i> Database Tables</h3>
                <div class="row">
                    <?php foreach ($table_status as $table => $status): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="status-item">
                            <strong><?php echo $table; ?>:</strong> <?php echo $status; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Quick Access Links -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-link"></i> Quick Access Links</h3>
                <div class="row text-center">
                    <div class="col-md-3">
                        <a href="index.php" class="btn btn-primary btn-lg mb-2">
                            <i class="fas fa-home"></i><br>Homepage
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="public-login.php" class="btn btn-success btn-lg mb-2">
                            <i class="fas fa-user"></i><br>Public Login
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="health_care/health_care_login.php" class="btn btn-info btn-lg mb-2">
                            <i class="fas fa-heartbeat"></i><br>Healthcare
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="worker_site/worker_sign_in.php" class="btn btn-warning btn-lg mb-2">
                            <i class="fas fa-hard-hat"></i><br>Worker
                        </a>
                    </div>
                </div>
                <div class="row text-center mt-3">
                    <div class="col-md-3">
                        <a href="muncipalty/officer-login.php" class="btn btn-danger btn-lg mb-2">
                            <i class="fas fa-user-tie"></i><br>Officer
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="ppp_page/public_sign_in.php" class="btn btn-secondary btn-lg mb-2">
                            <i class="fas fa-recycle"></i><br>PPP
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="government-site/government_page.html" class="btn btn-dark btn-lg mb-2">
                            <i class="fas fa-landmark"></i><br>Government
                        </a>
                    </div>
                    <div class="col-md-3">
                        <a href="system_test.php" class="btn btn-outline-primary btn-lg mb-2">
                            <i class="fas fa-sync"></i><br>Refresh Test
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- System Summary -->
        <div class="test-container">
            <div class="test-section">
                <h3><i class="fas fa-chart-bar"></i> System Summary</h3>
                <?php
                $total_dirs = count($dir_status);
                $existing_dirs = count(array_filter($dir_status, function($status) { return strpos($status, '✅') !== false; }));
                
                $total_files = count($file_status);
                $existing_files = count(array_filter($file_status, function($status) { return strpos($status, '✅') !== false; }));
                
                $total_tables = count($table_status);
                $existing_tables = count(array_filter($table_status, function($status) { return strpos($status, '✅') !== false; }));
                ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="status-item text-center">
                            <h4>Directories</h4>
                            <h2><?php echo $existing_dirs; ?>/<?php echo $total_dirs; ?></h2>
                            <p>Available</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="status-item text-center">
                            <h4>Files</h4>
                            <h2><?php echo $existing_files; ?>/<?php echo $total_files; ?></h2>
                            <p>Available</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="status-item text-center">
                            <h4>Database Tables</h4>
                            <h2><?php echo $existing_tables; ?>/<?php echo $total_tables; ?></h2>
                            <p>Available</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
