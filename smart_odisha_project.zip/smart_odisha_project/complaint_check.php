<?php
include 'connection.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header('Location: public-login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['id'];
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $comp_type = trim($_POST['comp-type']);
    $city = trim($_POST['city']);
    $address = trim($_POST['address']);
    $desc = trim($_POST['desc']);
    
    // Basic validation
    if (empty($name) || empty($phone) || empty($comp_type) || empty($city) || empty($address) || empty($desc)) {
        header('Location: Public_complaint.php?error=empty_fields');
        exit();
    }
    
    // Phone validation
    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        header('Location: Public_complaint.php?error=invalid_phone');
        exit();
    }
    
    // Handle file upload
    $image_name = '';
    if (isset($_FILES['uploadfile']) && $_FILES['uploadfile']['error'] == UPLOAD_ERR_OK) {
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];
        $filesize = $_FILES["uploadfile"]["size"];
        $filetype = $_FILES["uploadfile"]["type"];
        
        // Validate file type
        $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        if (!in_array($filetype, $allowed_types)) {
            header('Location: Public_complaint.php?error=invalid_file_type');
            exit();
        }
        
        // Validate file size (max 5MB)
        if ($filesize > 5 * 1024 * 1024) {
            header('Location: Public_complaint.php?error=file_too_large');
            exit();
        }
        
        // Generate unique filename
        $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
        $image_name = 'complaint_' . $user_id . '_' . time() . '.' . $file_extension;
        $folder = "./public_complain_image/" . $image_name;
        
        // Move uploaded file
        if (!move_uploaded_file($tempname, $folder)) {
            header('Location: Public_complaint.php?error=upload_failed');
            exit();
        }
    }
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "INSERT INTO public_complaint (id, comp_type, c_phone, comp_sts, comp_desc, c_img, c_address, c_city, c_date) 
            VALUES (?, ?, ?, 'open', ?, ?, ?, ?, CURDATE())";
    
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issssss", $user_id, $comp_type, $phone, $desc, $image_name, $address, $city);
        
        if (mysqli_stmt_execute($stmt)) {
            header('Location: public_complaint_page_for_p.php?success=complaint_submitted');
        } else {
            header('Location: Public_complaint.php?error=database_error');
        }
        
        mysqli_stmt_close($stmt);
    } else {
        header('Location: Public_complaint.php?error=database_error');
    }
} else {
    header('Location: Public_complaint.php');
}

mysqli_close($conn);
?>