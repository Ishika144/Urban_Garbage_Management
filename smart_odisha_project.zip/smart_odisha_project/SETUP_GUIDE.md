# Smart Odisha - Setup Guide for XAMPP

## 🚀 Quick Setup Instructions

### 1. XAMPP Server Setup
1. **Start XAMPP Control Panel**
2. **Start Apache and MySQL services**
3. **Verify both services are running (green status)**

### 2. Database Setup
1. **Open phpMyAdmin** (http://localhost/phpmyadmin)
2. **Create new database** named `garbage_manage`
3. **Import the database** using the SQL file:
   - Click on the `garbage_manage` database
   - Go to "Import" tab
   - Choose file: `c:\Users\OM PRASAD\Downloads\garbage_manage.sql`
   - Click "Go" to import

### 3. Project Setup
1. **Place project files** in XAMPP htdocs folder:
   ```
   C:\xampp\htdocs\smart_odisha_project\
   ```
2. **Access the project** at:
   ```
   http://localhost/smart_odisha_project/
   ```

### 4. Database Connection Test
1. **Run the setup script** to verify connection:
   ```
   http://localhost/smart_odisha_project/setup_database.php
   ```
2. **You should see**: "Database setup completed!"

## 🔧 Configuration Files

### Database Connection (`connection.php`)
```php
$servername = "localhost";
$username = "root";
$password = "";
$database = "garbage_manage";
```

### File Permissions
Ensure these folders have write permissions:
- `profile-image/`
- `public_complain_image/`
- `public-garbage-image/`

## 👥 Test Accounts

### Public User
- **Email**: saugatm3@gmail.com
- **Password**: asd

### Officer
- **ID**: 234
- **Password**: dfg

### Healthcare Provider
- **ID**: 2443
- **Password**: fgh

### PPP Partner
- **ID**: 2
- **Password**: dfg

### Workers
- **Worker 1**: santosh@gmail.com / vbn
- **Worker 2**: harish@gmail.com / zxc

## 🎯 Features Available

### For Public Users
- ✅ User registration and login
- ✅ Profile picture upload
- ✅ Submit garbage cleaning requests
- ✅ Submit complaints with images
- ✅ Track request status
- ✅ View complaint history

### For Municipal Officers
- ✅ Officer login
- ✅ View all complaints and requests
- ✅ Assign work to workers
- ✅ Update request status
- ✅ View worker assignments

### For Healthcare Providers
- ✅ Healthcare provider login
- ✅ Submit healthcare-related work
- ✅ Upload work images
- ✅ Track work status

### For PPP Partners
- ✅ PPP partner login
- ✅ Submit recycling work updates
- ✅ Upload work images
- ✅ Track approval status

### For Workers
- ✅ Worker login
- ✅ View assigned work
- ✅ Upload completion images
- ✅ Update work status

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check if MySQL is running in XAMPP
   - Verify database name is `garbage_manage`
   - Check username/password in `connection.php`

2. **Image Upload Not Working**
   - Check folder permissions
   - Verify folder paths exist
   - Check file size limits in PHP

3. **Page Not Loading**
   - Ensure Apache is running
   - Check file paths in htdocs
   - Verify PHP syntax

4. **Session Issues**
   - Check if sessions are enabled
   - Clear browser cookies
   - Restart Apache

### Error Messages

- **"Connection failed"**: MySQL not running
- **"Database not found"**: Import SQL file
- **"Permission denied"**: Check folder permissions
- **"File too large"**: Increase upload limits

## 📁 File Structure

```
smart_odisha_project/
├── connection.php              # Database connection
├── index.php                   # Homepage
├── public-login.php           # Public login
├── public-sign-up.php         # Public registration
├── public.php                 # Public dashboard
├── upload.php                 # Profile picture upload
├── image-upload.php           # Image upload handler
├── Public_complaint.php       # Complaint form
├── complaint_check.php        # Complaint handler
├── public_work_page_for_p.php # Garbage request form
├── garbage-rqst.php           # Garbage request handler
├── setup_database.php         # Database setup script
├── database_setup.sql         # Database schema
├── profile-image/             # Profile pictures
├── public_complain_image/     # Complaint images
├── public-garbage-image/      # Garbage request images
└── README.md                  # Project documentation
```

## 🔒 Security Features

- ✅ SQL injection prevention
- ✅ File upload validation
- ✅ Session management
- ✅ Input sanitization
- ✅ File type restrictions
- ✅ File size limits

## 🎨 UI/UX Improvements

- ✅ Modern responsive design
- ✅ Bootstrap 5 integration
- ✅ Font Awesome icons
- ✅ Google Fonts (Poppins)
- ✅ Gradient backgrounds
- ✅ Smooth animations
- ✅ Mobile-friendly layout
- ✅ Error handling with user feedback

## 📞 Support

If you encounter any issues:
1. Check the troubleshooting section
2. Verify XAMPP services are running
3. Check file permissions
4. Review error logs in XAMPP

## 🚀 Next Steps

After successful setup:
1. Test all user roles
2. Verify image uploads work
3. Check database operations
4. Test complaint and request submissions
5. Verify officer dashboard functionality

---

**Happy Coding! 🎉**





