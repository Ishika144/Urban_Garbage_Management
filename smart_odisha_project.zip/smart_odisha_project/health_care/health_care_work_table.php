<?php
session_start();
include '../connection.php';

// Check if healthcare provider is logged in
if (!isset($_SESSION['hid'])) {
    header('Location: health_care_login.php');
    exit();
}

$sql = "SELECT * FROM health_care_work,health_care_data WHERE health_care_work.hid=health_care_data.hid ORDER BY health_care_work.hwid DESC";
$result = mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Work History - Healthcare Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #27ae60;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .work-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .work-table h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background: #27ae60;
            color: white;
            border: none;
            font-weight: 600;
            padding: 15px;
        }
        
        .table tbody tr:hover {
            background: rgba(39, 174, 96, 0.1);
        }
        
        .table tbody td {
            padding: 15px;
            vertical-align: middle;
        }
        
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        
        .btn-view {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 0.9rem;
        }
        
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .back-btn {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-right: 10px;
        }
        
        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .work-table {
                margin-bottom: 20px;
                padding: 20px;
            }
            
            .table-responsive {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="health_care_work_check.php">
                <i class="fas fa-heartbeat"></i>Healthcare Dashboard
            </a>
            <div class="ms-auto">
                <a href="health_care_work_check.php" class="back-btn">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
                <a href="h_logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <div class="work-table">
                <h3><i class="fas fa-table me-2"></i>Work History</h3>
                
                <?php if (mysqli_num_rows($result) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-user me-2"></i>Healthcare Provider</th>
                                <th><i class="fas fa-phone me-2"></i>Phone</th>
                                <th><i class="fas fa-align-left me-2"></i>Description</th>
                                <th><i class="fas fa-image me-2"></i>Image</th>
                                <th><i class="fas fa-map-marker-alt me-2"></i>Address</th>
                                <th><i class="fas fa-city me-2"></i>City</th>
                                <th><i class="fas fa-tasks me-2"></i>Type</th>
                                <th><i class="fas fa-info-circle me-2"></i>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['name']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                <td>
                                    <div style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        <?php echo htmlspecialchars($row['h_w_desc']); ?>
                                    </div>
                                </td>
                                <td>
                                    <a href="../health_care_image/<?php echo htmlspecialchars($row['w_image']); ?>" 
                                       target="_blank" 
                                       class="btn btn-view">
                                        <i class="fas fa-eye me-1"></i>View
                                    </a>
                                </td>
                                <td><?php echo htmlspecialchars($row['w_address']); ?></td>
                                <td><?php echo htmlspecialchars($row['w_city']); ?></td>
                                <td>
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($row['w_type']); ?></span>
                                </td>
                                <td>
                                    <span class="status-badge <?php echo $row['w_status'] == 'Approved' ? 'status-approved' : 'status-pending'; ?>">
                                        <?php echo htmlspecialchars($row['w_status']); ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-clipboard-list"></i>
                    <h4>No Work Records Found</h4>
                    <p>There are no work records to display at the moment.</p>
                    <a href="health_care_data_upload.php" class="btn btn-view">
                        <i class="fas fa-plus me-2"></i>Upload New Work
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>