<?php
include '../connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $unique_id = trim($_POST['unique_id']);
    $password = trim($_POST['password']);

    // Basic validation
    if (empty($unique_id) || empty($password)) {
        header('Location: health_care_login.php?error=empty_fields');
        exit();
    }

    // Validate healthcare ID is numeric
    if (!is_numeric($unique_id)) {
        header('Location: health_care_login.php?error=invalid_credentials');
        exit();
    }

    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM health_care_data WHERE hid = ? AND hpassword = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $unique_id, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $count = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);

        if ($count == 1) {
            // Start session and store healthcare data
            session_start();
            $_SESSION['hid'] = $row['hid'];
            $_SESSION['hname'] = $row['hname'];
            $_SESSION['hemail'] = $row['hemail'];
            $_SESSION['hphone'] = $row['hphone'];
            $_SESSION['hgender'] = $row['hgender'];
            $_SESSION['hdp'] = $row['hdp'];
            $_SESSION['hdept'] = $row['hdept'];

            // Redirect to healthcare dashboard
            header('Location: health_care_work_check.php');
            exit();
        } else {
            // Invalid credentials
            header('Location: health_care_login.php?error=invalid_credentials');
            exit();
        }

        mysqli_stmt_close($stmt);
    } else {
        // Database error
        header('Location: health_care_login.php?error=database_error');
        exit();
    }
} else {
    // If accessed directly without POST
    header('Location: health_care_login.php');
    exit();
}

mysqli_close($conn);
?>