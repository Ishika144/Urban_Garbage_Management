<?php
session_start();
include '../connection.php';

// Check if healthcare provider is logged in
if (!isset($_SESSION['hid'])) {
    header('Location: health_care_login.php');
    exit();
}

// Get statistics
$hid = $_SESSION['hid'];
$total_work_sql = "SELECT COUNT(*) as total FROM health_care_work WHERE hid = ?";
$stmt = mysqli_prepare($conn, $total_work_sql);
mysqli_stmt_bind_param($stmt, "i", $hid);
mysqli_stmt_execute($stmt);
$total_result = mysqli_stmt_get_result($stmt);
$total_work = mysqli_fetch_assoc($total_result)['total'];

$approved_work_sql = "SELECT COUNT(*) as approved FROM health_care_work WHERE hid = ? AND w_status = 'Approved'";
$stmt = mysqli_prepare($conn, $approved_work_sql);
mysqli_stmt_bind_param($stmt, "i", $hid);
mysqli_stmt_execute($stmt);
$approved_result = mysqli_stmt_get_result($stmt);
$approved_work = mysqli_fetch_assoc($approved_result)['approved'];

$pending_work = $total_work - $approved_work;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Work - Healthcare Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #27ae60;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .stats-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
        }
        
        .stats-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .stats-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stats-label {
            color: #7f8c8d;
            font-size: 0.9rem;
        }
        
        .upload-form {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .upload-form h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .form-label {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #27ae60;
            box-shadow: 0 0 0 0.2rem rgba(39, 174, 96, 0.25);
            background: white;
        }
        
        .btn-upload {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .chart-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .chart-container h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .back-btn {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-right: 10px;
        }
        
        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .stats-card,
            .upload-form,
            .chart-container {
                margin-bottom: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="health_care_work_check.php">
                <i class="fas fa-heartbeat"></i>Healthcare Dashboard
            </a>
            <div class="ms-auto">
                <a href="health_care_work_check.php" class="back-btn">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
                <a href="h_logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <!-- Statistics Cards -->
            <div class="row">
                <div class="col-md-4">
                    <div class="stats-card text-center">
                        <i class="fas fa-clipboard-list stats-icon text-primary"></i>
                        <div class="stats-number text-primary"><?php echo $total_work; ?></div>
                        <div class="stats-label">Total Work</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card text-center">
                        <i class="fas fa-check-circle stats-icon text-success"></i>
                        <div class="stats-number text-success"><?php echo $approved_work; ?></div>
                        <div class="stats-label">Approved Work</div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stats-card text-center">
                        <i class="fas fa-clock stats-icon text-warning"></i>
                        <div class="stats-number text-warning"><?php echo $pending_work; ?></div>
                        <div class="stats-label">Pending Work</div>
                    </div>
                </div>
            </div>

            <!-- Chart -->
            <div class="chart-container">
                <h3>Work Statistics</h3>
                <div class="row">
                    <div class="col-md-8 mx-auto">
                        <canvas id="workChart" style="width: 100%; max-width: 600px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Upload Form -->
            <div class="upload-form">
                <h3><i class="fas fa-upload me-2"></i>Upload New Work</h3>
                
                <?php if (isset($_GET['success']) && $_GET['success'] == 'uploaded'): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>Work uploaded successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <form action="health_care_work_check.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="address" class="form-label">
                                    <i class="fas fa-map-marker-alt me-2"></i>Address
                                </label>
                                <input type="text" class="form-control" id="address" name="address" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="city" class="form-label">
                                    <i class="fas fa-city me-2"></i>City
                                </label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="type" class="form-label">
                                    <i class="fas fa-tasks me-2"></i>Work Type
                                </label>
                                <select class="form-select" id="type" name="type" required>
                                    <option selected disabled value="">Choose work type...</option>
                                    <option value="type-1">Type-1</option>
                                    <option value="type-2">Type-2</option>
                                    <option value="type-3">Type-3</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="uploadfile" class="form-label">
                                    <i class="fas fa-image me-2"></i>Work Image
                                </label>
                                <input type="file" class="form-control" id="uploadfile" name="uploadfile" accept="image/*" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="desc" class="form-label">
                            <i class="fas fa-align-left me-2"></i>Description
                        </label>
                        <textarea class="form-control" id="desc" name="desc" rows="4" placeholder="Enter work description..." required></textarea>
                    </div>
                    
                    <div class="text-center">
                        <button type="submit" name="upload" class="btn btn-upload">
                            <i class="fas fa-upload me-2"></i>Upload Work
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Chart configuration
        var ctx = document.getElementById('workChart').getContext('2d');
        var workChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Approved Work', 'Pending Work'],
                datasets: [{
                    data: [<?php echo $approved_work; ?>, <?php echo $pending_work; ?>],
                    backgroundColor: [
                        '#27ae60',
                        '#f39c12'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                legend: {
                    position: 'bottom',
                    labels: {
                        fontFamily: 'Poppins',
                        fontSize: 14,
                        fontColor: '#2c3e50'
                    }
                },
                tooltips: {
                    backgroundColor: 'rgba(0,0,0,0.8)',
                    titleFontFamily: 'Poppins',
                    bodyFontFamily: 'Poppins'
                }
            }
        });
    </script>
</body>
</html>