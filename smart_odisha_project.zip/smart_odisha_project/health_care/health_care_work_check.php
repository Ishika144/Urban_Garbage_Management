<?php
include '../connection.php';
session_start();

// Check if healthcare provider is logged in
if (!isset($_SESSION['hid'])) {
    header('Location: health_care_login.php');
    exit();
}

$id = $_SESSION['hid'];
$name = $_SESSION['hname'];
$phone = $_SESSION['hphone'];
$email = $_SESSION['hemail'];

// Only process POST data if form is submitted
if (isset($_POST['upload'])) {
    // Get form data with proper validation
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $city = isset($_POST['city']) ? trim($_POST['city']) : '';
    $type = isset($_POST['type']) ? trim($_POST['type']) : '';
    $desc = isset($_POST['desc']) ? trim($_POST['desc']) : '';

    // Validate required fields
    if (empty($address) || empty($city) || empty($type) || empty($desc)) {
        $error_message = "All fields are required.";
    } else {
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];
        $folder = "../health_care_image/" . $filename;
        
        // Validate file upload
        if ($_FILES["uploadfile"]["error"] == 0) {
            // Get all the submitted data from the form
            $sql = "INSERT INTO health_care_work(hid,name,phone,email,h_w_desc,w_image,w_address,w_city,w_type,w_status)VALUES(?,?,?,?,?,?,?,?,?,?)";
            
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt) {
                $status = 'pending';
                mysqli_stmt_bind_param($stmt, "isssssssss", $id, $name, $phone, $email, $desc, $filename, $address, $city, $type, $status);
                
                if (mysqli_stmt_execute($stmt)) {
                    // Now let's move the uploaded image into the folder: image
                    if (move_uploaded_file($tempname, $folder)) {
                        $success_message = "Work uploaded successfully!";
                        header('Location: health_care_data_upload.php?success=uploaded');
                        exit();
                    } else {
                        $error_message = "Failed to upload image!";
                    }
                } else {
                    $error_message = "Database error occurred!";
                }
                mysqli_stmt_close($stmt);
            } else {
                $error_message = "Database error occurred!";
            }
        } else {
            $error_message = "File upload error occurred!";
        }
    }
}

// Get healthcare provider's work history
$work_sql = "SELECT * FROM health_care_work WHERE hid = ? ORDER BY hwid DESC";
$work_stmt = mysqli_prepare($conn, $work_sql);
mysqli_stmt_bind_param($work_stmt, "i", $id);
mysqli_stmt_execute($work_stmt);
$work_result = mysqli_stmt_get_result($work_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Healthcare Dashboard - Smart Odisha</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #27ae60;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .welcome-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .welcome-section h2 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .welcome-section p {
            color: #7f8c8d;
            margin-bottom: 0;
        }
        
        .profile-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .profile-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #27ae60;
            margin-bottom: 20px;
        }
        
        .profile-info h4 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 15px;
        }
        
        .profile-info p {
            color: #7f8c8d;
            margin-bottom: 8px;
        }
        
        .profile-info strong {
            color: #2c3e50;
        }
        
        .action-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .action-card h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .btn-action {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 15px 30px;
            border-radius: 10px;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            transition: all 0.3s ease;
            min-width: 200px;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .btn-action.blue {
            background: linear-gradient(135deg, #3498db, #2980b9);
        }
        
        .btn-action.blue:hover {
            box-shadow: 0 10px 20px rgba(52, 152, 219, 0.3);
        }
        
        .btn-action.orange {
            background: linear-gradient(135deg, #f39c12, #e67e22);
        }
        
        .btn-action.orange:hover {
            box-shadow: 0 10px 20px rgba(243, 156, 18, 0.3);
        }
        
        .work-table {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .work-table h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 25px;
            text-align: center;
        }
        
        .table {
            border-radius: 10px;
            overflow: hidden;
        }
        
        .table thead th {
            background: #27ae60;
            color: white;
            border: none;
            font-weight: 600;
        }
        
        .table tbody tr:hover {
            background: rgba(39, 174, 96, 0.1);
        }
        
        .status-badge {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .welcome-section,
            .profile-card,
            .action-card,
            .work-table {
                margin-bottom: 20px;
                padding: 20px;
            }
            
            .btn-action {
                min-width: 100%;
                margin: 5px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-heartbeat"></i>Healthcare Dashboard
            </a>
            <div class="ms-auto">
                <a href="h_logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2>Welcome back, <?php echo htmlspecialchars($name); ?>!</h2>
                        <p>Manage your healthcare work and upload reports efficiently.</p>
                    </div>
                    <div class="col-md-4 text-end">
                        <small class="text-muted"><?php echo date('l, F j, Y'); ?></small>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Profile Card -->
                <div class="col-lg-4">
                    <div class="profile-card">
                        <div class="text-center">
                            <img src="../health_care_image/<?php echo htmlspecialchars($_SESSION['hdp']); ?>" 
                                 alt="Profile" 
                                 class="profile-image"
                                 onerror="this.src='../health_care_image/default.jpg'">
                            
                            <div class="profile-info">
                                <h4><?php echo htmlspecialchars($name); ?></h4>
                                <p><strong>Department:</strong> <?php echo htmlspecialchars($_SESSION['hdept']); ?></p>
                                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                                <p><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></p>
                                <p><strong>Gender:</strong> <?php echo htmlspecialchars($_SESSION['hgender']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="col-lg-8">
                    <div class="action-card">
                        <h3>Quick Actions</h3>
                        <div class="row text-center">
                            <div class="col-md-6">
                                <a href="health_care_data_upload.php" class="btn btn-action">
                                    <i class="fas fa-upload me-2"></i>Upload Work
                                </a>
                            </div>
                            <div class="col-md-6">
                                <a href="health_care_work_table.php" class="btn btn-action blue">
                                    <i class="fas fa-table me-2"></i>View Work History
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Work History Table -->
            <div class="work-table">
                <h3>Recent Work History</h3>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Work ID</th>
                                <th>Description</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($work_result)) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['hwid']); ?></td>
                                <td><?php echo htmlspecialchars($row['h_w_desc']); ?></td>
                                <td><?php echo htmlspecialchars($row['w_address']); ?></td>
                                <td><?php echo htmlspecialchars($row['w_city']); ?></td>
                                <td><?php echo htmlspecialchars($row['w_type']); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $row['w_status'] == 'Approved' ? 'status-approved' : 'status-pending'; ?>">
                                        <?php echo htmlspecialchars($row['w_status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($row['hwid'])); ?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>