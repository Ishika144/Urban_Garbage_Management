# Smart Odisha - Garbage Management System

A comprehensive web-based garbage management system for the state of Odisha, designed to connect citizens, municipal authorities, healthcare providers, and private sector partners for efficient waste management.

## 🌟 Features

### For Citizens (Public)
- **User Registration & Login**: Secure authentication system
- **Garbage Reporting**: Upload photos and report garbage issues
- **Complaint Management**: Submit and track complaints
- **Request Tracking**: Monitor the status of cleaning requests
- **Profile Management**: Update personal information and profile pictures

### For Municipal Authorities
- **Dashboard**: Overview of all complaints and requests
- **Task Assignment**: Assign work to field workers
- **Status Updates**: Update progress on complaints and requests
- **Worker Management**: Manage worker assignments and performance

### For Healthcare Providers
- **Medical Waste Reporting**: Specialized reporting for medical waste
- **Coordination**: Direct communication with municipal authorities
- **Compliance Tracking**: Monitor waste disposal compliance

### For Private Sector (PPP)
- **Partnership Portal**: Dedicated interface for private partners
- **Project Management**: Track partnership projects
- **Reporting**: Generate reports and analytics

### For Workers
- **Task Management**: View assigned tasks and update progress
- **Communication**: Direct communication with supervisors
- **Work Tracking**: Log completed work and time spent

## 🚀 Quick Start

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache/Nginx web server
- XAMPP/WAMP/MAMP (for local development)

### Installation

1. **Clone or Download the Project**
   ```bash
   git clone <repository-url>
   cd smart_odisha_project
   ```

2. **Database Setup**
   - Start your MySQL server
   - Open phpMyAdmin or MySQL command line
   - Import the `database_setup.sql` file to create the database and tables
   - Or run the SQL commands manually:
   ```sql
   CREATE DATABASE garbage_manage;
   USE garbage_manage;
   -- Then run all the CREATE TABLE statements from database_setup.sql
   ```

3. **Configure Database Connection**
   - Open `connection.php`
   - Update the database credentials if needed:
   ```php
   $servername = "localhost";
   $username = "root";
   $password = "";
   $database = "garbage_manage";
   ```

4. **Web Server Configuration**
   - Place the project in your web server's document root
   - For XAMPP: `C:\xampp\htdocs\smart_odisha_project\`
   - For WAMP: `C:\wamp\www\smart_odisha_project\`

5. **Access the Application**
   - Open your web browser
   - Navigate to: `http://localhost/smart_odisha_project/`

## 📁 Project Structure

```
smart_odisha_project/
├── index.php                          # Main landing page
├── connection.php                     # Database connection
├── database_setup.sql                 # Database schema
├── public-login.php                   # Public user login
├── public-sign-up.php                 # Public user registration
├── public.php                         # Public user dashboard
├── public-check.php                   # Login authentication
├── send.php                          # Logout functionality
├── upload.php                        # Profile picture upload
├── public_complaint.php              # Complaint submission
├── public-upload-garbage-image.php   # Garbage image upload
├── public_work_page_for_p.php        # View work requests
├── public_complaint_page_for_p.php   # View complaint status
├── muncipalty/                       # Municipality portal
│   ├── officer-login.php
│   ├── OFFICER_PAGE.php
│   └── ...
├── health_care/                      # Healthcare provider portal
│   ├── health_care_login.php
│   └── ...
├── ppp_page/                         # Private sector portal
│   ├── public_sign_in.php
│   └── ...
├── worker_site/                      # Worker portal
│   ├── worker_sign_in.php
│   └── ...
├── government-site/                  # Government portal
│   └── government_page.html
├── profile-image/                    # User profile images
├── public_complain_image/            # Complaint images
├── public-garbage-image/             # Garbage report images
└── README.md                         # This file
```

## 🔐 Default Login Credentials

### Municipality Officer
- **Username**: admin
- **Password**: admin123

### Healthcare Provider
- **Username**: healthcare1
- **Password**: health123

### PPP Partner
- **Username**: ppp1
- **Password**: ppp123

### Worker
- **Username**: worker1
- **Password**: worker123

## 🎨 Design Features

- **Modern UI/UX**: Clean, responsive design with Bootstrap 5
- **Interactive Elements**: Hover effects, animations, and smooth transitions
- **Mobile Responsive**: Works perfectly on all device sizes
- **Accessibility**: Proper contrast ratios and keyboard navigation
- **Professional Color Scheme**: Green theme representing environmental consciousness

## 🔧 Technical Features

- **Secure Authentication**: Session-based user management
- **File Upload**: Image upload with validation
- **Database Security**: Prepared statements and input validation
- **Responsive Design**: Mobile-first approach
- **Cross-browser Compatibility**: Works on all modern browsers

## 🛠️ Customization

### Changing Colors
The primary color scheme uses green tones (#27ae60, #2ecc71). To change colors:
1. Update CSS variables in the style sections
2. Modify gradient backgrounds
3. Update button colors and hover effects

### Adding New Features
1. Create new PHP files for functionality
2. Add corresponding database tables if needed
3. Update navigation menus
4. Test thoroughly across different user roles

## 📱 Mobile Optimization

The system is fully responsive and optimized for mobile devices:
- Touch-friendly buttons and navigation
- Optimized image sizes
- Collapsible navigation menu
- Proper viewport settings

## 🔒 Security Considerations

- **Input Validation**: All user inputs are validated
- **SQL Injection Prevention**: Using prepared statements
- **Session Management**: Secure session handling
- **File Upload Security**: Image validation and size limits
- **Password Security**: Consider implementing password hashing

## 🚀 Deployment

### Local Development
1. Use XAMPP/WAMP/MAMP for local development
2. Ensure all PHP extensions are enabled
3. Configure virtual hosts if needed

### Production Deployment
1. Use a production web server (Apache/Nginx)
2. Configure SSL certificates for HTTPS
3. Set up proper database credentials
4. Implement proper security measures
5. Regular backups of database and files

## 📞 Support

For technical support or questions:
- Email: info@smartodisha.gov.in
- Phone: +91 674 234 5678

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is developed for the Government of Odisha and is intended for public use.

## 🎯 Future Enhancements

- **Real-time Notifications**: Push notifications for status updates
- **Mobile App**: Native mobile applications
- **AI Integration**: Smart routing and task optimization
- **Analytics Dashboard**: Advanced reporting and analytics
- **API Integration**: Third-party service integrations
- **Multi-language Support**: Support for multiple languages

---

**Developed with ❤️ for a cleaner Odisha**

