<?php
session_start();

// Destroy all session data
session_destroy();

// Redirect to the main index page
header('Location: ../index.php?logout=success');
exit();
?>

