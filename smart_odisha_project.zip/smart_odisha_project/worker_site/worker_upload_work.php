<?php
session_start();
include '../connection.php';

// Check if worker is logged in
if (!isset($_SESSION['wid'])) {
    header('Location: worker_sign_in.php');
    exit();
}

// Process form submission
if (isset($_POST['upload'])) {
    $wid = $_SESSION['wid'];
    $work_address = isset($_POST['work_address']) ? trim($_POST['work_address']) : '';
    $work_description = isset($_POST['work_description']) ? trim($_POST['work_description']) : '';
    
    if (empty($work_address) || empty($work_description)) {
        $error_message = "All fields are required.";
    } else {
        $filename = $_FILES["work_image"]["name"];
        $tempname = $_FILES["work_image"]["tmp_name"];
        $folder = "../worker_work_image/" . $filename;
        
        if ($_FILES["work_image"]["error"] == 0) {
            $sql = "INSERT INTO worker_work(wid, w_address, w_desc, w_image, w_status) VALUES (?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt) {
                $status = 'Pending';
                mysqli_stmt_bind_param($stmt, "issss", $wid, $work_address, $work_description, $filename, $status);
                
                if (mysqli_stmt_execute($stmt)) {
                    if (move_uploaded_file($tempname, $folder)) {
                        $success_message = "Work uploaded successfully!";
                        header('Location: worker_upload_work.php?success=uploaded');
                        exit();
                    } else {
                        $error_message = "Failed to upload image!";
                    }
                } else {
                    $error_message = "Database error occurred!";
                }
                mysqli_stmt_close($stmt);
            } else {
                $error_message = "Database error occurred!";
            }
        } else {
            $error_message = "File upload error occurred!";
        }
    }
}

// Get worker data
$wid = $_SESSION['wid'];
$worker_sql = "SELECT * FROM worker_data WHERE wid = ?";
$stmt = mysqli_prepare($conn, $worker_sql);
mysqli_stmt_bind_param($stmt, "i", $wid);
mysqli_stmt_execute($stmt);
$worker_result = mysqli_stmt_get_result($stmt);
$worker = mysqli_fetch_assoc($worker_result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Work - Worker Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            padding: 15px 0;
        }
        
        .navbar-brand {
            font-weight: 700;
            color: #2c3e50;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            color: #9b59b6;
            margin-right: 10px;
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .upload-form {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .upload-form h3 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .form-label {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f8f9fa;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #9b59b6;
            box-shadow: 0 0 0 0.2rem rgba(155, 89, 182, 0.25);
            background: white;
        }
        
        .btn-upload {
            background: linear-gradient(135deg, #9b59b6, #8e44ad);
            border: none;
            color: white;
            padding: 15px 40px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            width: 100%;
        }
        
        .btn-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(155, 89, 182, 0.3);
            color: white;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #e74c3c, #c0392b);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.3);
            color: white;
        }
        
        .back-btn {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border: none;
            color: white;
            padding: 8px 20px;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            margin-right: 10px;
        }
        
        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
            color: white;
        }
        
        .alert {
            border-radius: 10px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 20px;
        }
        
        .worker-info {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .worker-info h4 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 20px;
        }
        
        .worker-info p {
            color: #7f8c8d;
            margin-bottom: 8px;
        }
        
        .worker-info strong {
            color: #2c3e50;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .upload-form,
            .worker-info {
                margin-bottom: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="WorkerProfile.html">
                <i class="fas fa-hard-hat"></i>Worker Dashboard
            </a>
            <div class="ms-auto">
                <a href="WorkerProfile.html" class="back-btn">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
                <a href="worker_logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <!-- Worker Info -->
            <div class="worker-info">
                <h4><i class="fas fa-user me-2"></i>Worker Information</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($worker['wname']); ?></p>
                        <p><strong>Department:</strong> <?php echo htmlspecialchars($worker['wdept']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($worker['wemail']); ?></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($worker['wphone']); ?></p>
                        <p><strong>DOB:</strong> <?php echo htmlspecialchars($worker['wdob']); ?></p>
                        <p><strong>Gender:</strong> <?php echo htmlspecialchars($worker['wgender']); ?></p>
                    </div>
                </div>
            </div>

            <!-- Upload Form -->
            <div class="upload-form">
                <h3><i class="fas fa-upload me-2"></i>Upload Work Report</h3>
                
                <?php if (isset($_GET['success']) && $_GET['success'] == 'uploaded'): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>Work uploaded successfully!
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <?php if (isset($error_message)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php endif; ?>
                
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="work_address" class="form-label">
                                    <i class="fas fa-map-marker-alt me-2"></i>Work Address
                                </label>
                                <input type="text" class="form-control" id="work_address" name="work_address" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="work_image" class="form-label">
                                    <i class="fas fa-image me-2"></i>Work Image
                                </label>
                                <input type="file" class="form-control" id="work_image" name="work_image" accept="image/*" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="work_description" class="form-label">
                            <i class="fas fa-align-left me-2"></i>Work Description
                        </label>
                        <textarea class="form-control" id="work_description" name="work_description" rows="4" placeholder="Describe the work completed..." required></textarea>
                    </div>
                    
                    <div class="text-center">
                        <button type="submit" name="upload" class="btn btn-upload">
                            <i class="fas fa-upload me-2"></i>Upload Work Report
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

