<?php
include '../connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Basic validation
    if (empty($email) || empty($password)) {
        header('Location: worker_sign_in.php?error=empty_fields');
        exit();
    }

    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header('Location: worker_sign_in.php?error=invalid_credentials');
        exit();
    }

    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT * FROM worker_data WHERE wor_email = ? AND w_password = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", $email, $password);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $count = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);

        if ($count == 1) {
            // Start session and store worker data
            session_start();
            $_SESSION['worker_id'] = $row['worker_id'];
            $_SESSION['worker_name'] = $row['worker_name'];
            $_SESSION['wor_email'] = $row['wor_email'];
            $_SESSION['wor_phone'] = $row['wor_phone'];
            $_SESSION['wor_gender'] = $row['wor_gender'];
            $_SESSION['wor_dp'] = $row['wor_dp'];
            $_SESSION['wor_dept'] = $row['wor_dept'];
            $_SESSION['wor_address'] = $row['wor_address'];
            $_SESSION['wor_city'] = $row['wor_city'];

            // Redirect to worker dashboard
            header('Location: WorkerProfile.html');
            exit();
        } else {
            // Invalid credentials
            header('Location: worker_sign_in.php?error=invalid_credentials');
            exit();
        }

        mysqli_stmt_close($stmt);
    } else {
        // Database error
        header('Location: worker_sign_in.php?error=database_error');
        exit();
    }
} else {
    // If accessed directly without POST
    header('Location: worker_sign_in.php');
    exit();
}

mysqli_close($conn);
?>

