<?php
// Test script to verify login systems are working
echo "<h2>Testing Login Systems</h2>";

// Test 1: Check if connection.php can be included from subdirectories
echo "<h3>Test 1: Database Connection from Subdirectories</h3>";

// Test worker directory
echo "<p>Testing worker_site/worker_check.php include path...</p>";
try {
    include 'worker_site/worker_check.php';
    echo "<p style='color: green;'>✓ worker_site/worker_check.php can include connection.php successfully</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error in worker_site/worker_check.php: " . $e->getMessage() . "</p>";
}

// Test healthcare directory
echo "<p>Testing health_care/health_care_check.php include path...</p>";
try {
    include 'health_care/health_care_check.php';
    echo "<p style='color: green;'>✓ health_care/health_care_check.php can include connection.php successfully</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>✗ Error in health_care/health_care_check.php: " . $e->getMessage() . "</p>";
}

// Test 2: Check database connection
echo "<h3>Test 2: Database Connection</h3>";
include 'connection.php';
if ($conn) {
    echo "<p style='color: green;'>✓ Database connection successful</p>";
    
    // Test 3: Check if tables exist
    echo "<h3>Test 3: Database Tables</h3>";
    
    $tables = ['worker_data', 'health_care_data', 'public_data', 'officer_data', 'ppp_data'];
    
    foreach ($tables as $table) {
        $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
        if (mysqli_num_rows($result) > 0) {
            echo "<p style='color: green;'>✓ Table '$table' exists</p>";
        } else {
            echo "<p style='color: red;'>✗ Table '$table' does not exist</p>";
        }
    }
    
    // Test 4: Check sample data
    echo "<h3>Test 4: Sample Data</h3>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM worker_data");
    $row = mysqli_fetch_assoc($result);
    echo "<p>Worker records: " . $row['count'] . "</p>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM health_care_data");
    $row = mysqli_fetch_assoc($result);
    echo "<p>Healthcare records: " . $row['count'] . "</p>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM public_data");
    $row = mysqli_fetch_assoc($result);
    echo "<p>Public records: " . $row['count'] . "</p>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM officer_data");
    $row = mysqli_fetch_assoc($result);
    echo "<p>Officer records: " . $row['count'] . "</p>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as count FROM ppp_data");
    $row = mysqli_fetch_assoc($result);
    echo "<p>PPP records: " . $row['count'] . "</p>";
    
} else {
    echo "<p style='color: red;'>✗ Database connection failed</p>";
}

echo "<h3>Test Complete!</h3>";
echo "<p><a href='index.php'>Go to Homepage</a></p>";
?>



