<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('Location: public-login.php');
    exit();
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Smart Odisha</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
        }
        
        .navbar {
            background: linear-gradient(135deg, #27ae60, #2ecc71) !important;
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-brand {
            font-weight: 700;
            color: white !important;
            font-size: 1.5rem;
        }
        
        .navbar-brand i {
            margin-right: 10px;
        }
        
        .nav-link {
            color: white !important;
            font-weight: 500;
            transition: all 0.3s ease;
            margin: 0 5px;
            border-radius: 8px;
            padding: 8px 15px !important;
        }
        
        .nav-link:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }
        
        .main-content {
            padding: 30px 0;
        }
        
        .welcome-section {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-left: 5px solid #27ae60;
        }
        
        .welcome-title {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .welcome-subtitle {
            color: #7f8c8d;
            font-size: 1.1rem;
        }
        
        .profile-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .profile-image {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #27ae60;
            margin-bottom: 20px;
        }
        
        .profile-info h5 {
            color: #2c3e50;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .profile-info p {
            color: #7f8c8d;
            margin-bottom: 15px;
        }
        
        .stats-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            height: 100%;
            border-top: 4px solid #27ae60;
        }
        
        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .stats-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 1.5rem;
        }
        
        .stats-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: #27ae60;
            margin-bottom: 10px;
        }
        
        .stats-label {
            color: #7f8c8d;
            font-weight: 500;
        }
        
        .action-card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            height: 100%;
            border: 2px solid transparent;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
            border-color: #27ae60;
        }
        
        .action-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            color: white;
            font-size: 2rem;
        }
        
        .action-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 15px;
        }
        
        .action-description {
            color: #7f8c8d;
            margin-bottom: 25px;
            line-height: 1.6;
        }
        
        .btn-action {
            background: linear-gradient(135deg, #27ae60, #2ecc71);
            border: none;
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(39, 174, 96, 0.3);
            color: white;
        }
        
        .logout-btn {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
        }
        
        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.3);
            color: white;
        }
        
        @media (max-width: 768px) {
            .main-content {
                padding: 20px 0;
            }
            
            .profile-card, .stats-card, .action-card {
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-recycle"></i>
                Smart Odisha
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="upload.php">
                            <i class="fas fa-camera me-1"></i>Upload Photo
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="public_complaint.php">
                            <i class="fas fa-comment me-1"></i>Write Complaint
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="public_work_page_for_p.php">
                            <i class="fas fa-list me-1"></i>View Requests
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="public_complaint_page_for_p.php">
                            <i class="fas fa-tasks me-1"></i>Complaint Status
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="logout-btn" href="send.php">
                            <i class="fas fa-sign-out-alt me-1"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <!-- Welcome Section -->
            <div class="welcome-section">
                <h2 class="welcome-title">
                    <i class="fas fa-user-circle me-2"></i>
                    Welcome back, <?php echo $_SESSION['fname'] . ' ' . $_SESSION['lname']; ?>!
                </h2>
                <p class="welcome-subtitle">Manage your garbage requests and track the progress of your complaints</p>
            </div>

            <div class="row">
                <!-- Profile Card -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="profile-card">
                        <div class="text-center">
                            <img src="./profile-image/<?php echo $_SESSION['image'] ?: 'default.jpg'; ?>" 
                                 alt="Profile Picture" class="profile-image">
                            <div class="profile-info">
                                <h5><i class="fas fa-user me-2"></i><?php echo $_SESSION['fname'] . ' ' . $_SESSION['lname']; ?></h5>
                                <p><i class="fas fa-envelope me-2"></i><?php echo $_SESSION['email']; ?></p>
                                <p><i class="fas fa-phone me-2"></i><?php echo $_SESSION['phone']; ?></p>
                                <p><i class="fas fa-venus-mars me-2"></i><?php echo $_SESSION['gender']; ?></p>
                                <p><i class="fas fa-calendar me-2"></i><?php echo $_SESSION['dob']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="stats-card">
                        <div class="stats-icon">
                            <i class="fas fa-check-circle"></i>
                        </div>
                        <div class="stats-number">0</div>
                        <div class="stats-label">Completed Requests</div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="stats-card">
                        <div class="stats-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="stats-number">0</div>
                        <div class="stats-label">Pending Requests</div>
                    </div>
                </div>
            </div>

            <!-- Action Cards -->
            <div class="row">
                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-trash"></i>
                        </div>
                        <h3 class="action-title">Garbage Cleaning Request</h3>
                        <p class="action-description">
                            Report garbage issues in your area. Upload photos and provide location details for quick resolution.
                        </p>
                        <a href="public-upload-garbage-image.php" class="btn-action">
                            <i class="fas fa-plus me-2"></i>Make Request
                        </a>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 mb-4">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-broom"></i>
                        </div>
                        <h3 class="action-title">Personal Cleaning Request</h3>
                        <p class="action-description">
                            Request personal cleaning services for your property or specific areas that need attention.
                        </p>
                        <a href="#" class="btn-action">
                            <i class="fas fa-plus me-2"></i>Make Request
                        </a>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-comment-dots"></i>
                        </div>
                        <h3 class="action-title">Write Complaint</h3>
                        <p class="action-description">
                            Submit complaints about garbage issues, maintenance problems, or other concerns.
                        </p>
                        <a href="public_complaint.php" class="btn-action">
                            <i class="fas fa-edit me-2"></i>Write Now
                        </a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-list-alt"></i>
                        </div>
                        <h3 class="action-title">View All Requests</h3>
                        <p class="action-description">
                            Check the status of all your cleaning requests and track their progress.
                        </p>
                        <a href="public_work_page_for_p.php" class="btn-action">
                            <i class="fas fa-eye me-2"></i>View Requests
                        </a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3 class="action-title">Complaint Status</h3>
                        <p class="action-description">
                            Monitor the status of your complaints and see updates from municipal authorities.
                        </p>
                        <a href="public_complaint_page_for_p.php" class="btn-action">
                            <i class="fas fa-search me-2"></i>Check Status
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Add some interactive effects
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stats cards on load
            const statsCards = document.querySelectorAll('.stats-card');
            statsCards.forEach((card, index) => {
                setTimeout(() => {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(30px)';
                    card.style.transition = 'all 0.6s ease';
                    
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                }, index * 200);
            });
            
            // Add hover effects to action cards
            const actionCards = document.querySelectorAll('.action-card');
            actionCards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-10px) scale(1.02)';
                });
                
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });
    </script>
</body>
</html>