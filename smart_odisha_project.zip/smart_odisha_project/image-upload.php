<?php
include 'connection.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header('Location: public-login.php');
    exit();
}

$id = $_SESSION['id'];

if (isset($_POST['upload'])) {
    // Check if file was uploaded
    if (!isset($_FILES['uploadfile']) || $_FILES['uploadfile']['error'] !== UPLOAD_ERR_OK) {
        echo "<h3>Error: Please select a file to upload!</h3>";
        echo "<a href='upload.php'>Go Back</a>";
        exit();
    }
    
    $filename = $_FILES["uploadfile"]["name"];
    $tempname = $_FILES["uploadfile"]["tmp_name"];
    $filesize = $_FILES["uploadfile"]["size"];
    $filetype = $_FILES["uploadfile"]["type"];
    
    // Validate file type
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    if (!in_array($filetype, $allowed_types)) {
        echo "<h3>Error: Only JPG, JPEG, PNG & GIF files are allowed!</h3>";
        echo "<a href='upload.php'>Go Back</a>";
        exit();
    }
    
    // Validate file size (max 5MB)
    if ($filesize > 5 * 1024 * 1024) {
        echo "<h3>Error: File size must be less than 5MB!</h3>";
        echo "<a href='upload.php'>Go Back</a>";
        exit();
    }
    
    // Generate unique filename
    $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
    $unique_filename = 'profile_' . $id . '_' . time() . '.' . $file_extension;
    $folder = "./profile-image/" . $unique_filename;
    
    // Prepare SQL statement to prevent SQL injection
    $sql = "UPDATE public_data SET file_name = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "si", $unique_filename, $id);
        
        // Execute query
        if (mysqli_stmt_execute($stmt)) {
            // Move uploaded file
            if (move_uploaded_file($tempname, $folder)) {
                echo "<div style='text-align: center; margin-top: 50px;'>";
                echo "<h3 style='color: green;'>Image uploaded successfully!</h3>";
                echo "<p>Your profile picture has been updated.</p>";
                echo "<a href='public.php' style='background: #27ae60; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Dashboard</a>";
                echo "</div>";
                
                // Redirect after 3 seconds
                header("refresh:3;url=public.php");
            } else {
                echo "<h3>Error: Failed to move uploaded file!</h3>";
                echo "<a href='upload.php'>Go Back</a>";
            }
        } else {
            echo "<h3>Error: Failed to update database!</h3>";
            echo "<a href='upload.php'>Go Back</a>";
        }
        
        mysqli_stmt_close($stmt);
    } else {
        echo "<h3>Error: Database error!</h3>";
        echo "<a href='upload.php'>Go Back</a>";
    }
}

mysqli_close($conn);
?>