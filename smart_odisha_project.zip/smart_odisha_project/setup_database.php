<?php
// Database setup script for XAMPP
$servername = "localhost";
$username = "root";
$password = "";

try {
    // Create connection without database
    $conn = new mysqli($servername, $username, $password);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Create database if not exists
    $sql = "CREATE DATABASE IF NOT EXISTS garbage_manage";
    if ($conn->query($sql) === TRUE) {
        echo "Database 'garbage_manage' created successfully or already exists<br>";
    } else {
        echo "Error creating database: " . $conn->error . "<br>";
    }
    
    // Select the database
    $conn->select_db("garbage_manage");
    
    // Read and execute the SQL file
    $sqlFile = file_get_contents('database_setup.sql');
    
    // Split the SQL file into individual queries
    $queries = explode(';', $sqlFile);
    
    foreach ($queries as $query) {
        $query = trim($query);
        if (!empty($query)) {
            if ($conn->query($query) === TRUE) {
                echo "Query executed successfully<br>";
            } else {
                echo "Error executing query: " . $conn->error . "<br>";
                echo "Query: " . $query . "<br><br>";
            }
        }
    }
    
    echo "<br>Database setup completed!<br>";
    echo "<a href='index.php'>Go to Homepage</a>";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

$conn->close();
?>





